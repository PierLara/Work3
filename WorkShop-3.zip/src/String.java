public class String {
}
