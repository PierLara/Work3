import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in).useDelimiter("\n");

        System.out.println("Bienvenido a la aplicación de gestión de tareas más cuca del barrio. \n Por favor, seleccione una opción para continuar");
        int opcion = 0;
        do {
            System.out.println("1. Ingresar una tarea");
            System.out.println("2. Completar una tarea");
            System.out.println("3. Listar las tareas pendientes");
            System.out.println("4. Listar las tareas completas");
            System.out.println("5. Listar todas las tareas");
            System.out.println("6. Eliminar una tarea");
            System.out.println("7. Actualizar una tarea");
            System.out.println("8. Ver detalle de tarea");
            System.out.println("9. Salir");
            opcion = leer.nextInt();

            switch(opcion) {
                case 1:
                    System.out.println("Crear tarea nueva");
                    System.out.println("Ingrese la descripcion de la tarea");
                    String tarea = leer.next();
                    TodoList.agregarTarea(tarea);
                    System.out.println("La tarea se ha agregado");
                    break;
                case 2:
                    System.out.println("Completar una tarea");
                    System.out.println("Lista de todas las tareas");

                    System.out.println("Ingrese el indice de la tarea a completar");
                    int indice = leer.nextInt();
                    System.out.println("Ingrese loos munitos que demoro haciedno la tarea");
                    int minutos = leer.nextInt();
                    Todolist.completarTarea(indice,minutos);
                    System.out.println("La tarea se completo");
                    break;
                case 3:
                    System.out.println("Lista de tareas pendientes");
                    String listaTareaspendientes = TodoList.listarTreasPendientes();
                    System.out.println(listaTareasPendientes);
                    break;
                case 4:
                    System.out.println("Lista de tareas completas");
                    String listaTareasCompletadas = TodoList.listarTareasComplatas();
                    System.out.println(listaTareasCompletadas);
                    break;
                case 5:
                    System.out.println("Lista de todas las  tareas");
                    String listaTareas = TodoList.listarTareas();
                    System.out.println(listaTareas);
                    break;
                case 6:
                    System.out.println("Eliminar una tarea");
                    System.out.println("Ingrese la posicion de la tarea a eliminar");
                    int elimina = leer.nextInt();
                    boolean eliminardetalle = TodoList.eliminarTarea(elimina);
                    if(eliminardetalle) {
                        System.out.println("La tarea se elimino");
                    }else {
                        System.out.println("La tarea que desea eliminar no existe, por favor verificar el nombre de la trea");
                    }
                    System.out.println(eliminardetalle);
                    break;
                case 7:
                    System.out.println("Actualizar una tarea");
                    System.out.println("Lista de todas las tareas");
                    System.out.println("Ingresar la pocición de la tarea que quiere Actualizar");
                    int busca = leer.nextInt();
                    System.out.println("Ingrese la actualización del registro para la tarea");
                    String actualizardescripcion = leer.nextInt();
                    System.out.println("El registro se ha cambiado corecctamente");
                    TodoList.Actualiza(busca,actualizardescripcion);
                    break;
                case 8:
                    System.out.println("Ver detalles de una tarea");
                    System.out.println("Ingrese la pocicion de la tarea sobre la cual quiere ver los detalles");
                    int idDetalle = leer.nextInt();
                    string detalle = TodoList.detalleTarea(idDetalle);
                    System.out.println(detalle);
                    break;
                case 9:
                    System.out.println("Gracias por confiarnos tus tareas, hasta la proxima");
                    break;
            }

        } while (opcion != 9);
    }
}