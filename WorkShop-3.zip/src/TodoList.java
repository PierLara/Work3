import java.util.ArrayList;
import java.util.List;

public class TodoList {
    public static List<String[]> listaDeTareas = new ArrayList<>();

    public static void agregarTarea(String descripcionTarea){
        // arr[i] = valor
        String[] tarea = new String[3];
        tarea[0] = descripcionTarea;
        tarea[1] = String.valueOf(false);
        tarea[2] = String.valueOf(0);
        listaDeTareas.add(tarea);
    }

public static void completartarea(int i, int min) {
    String[] tarea = listaDeTareas.get(1);
    tarea[1] = String.valueOf(true);
    tarea[2] = String.valueOf(min);
}

public static string listarTareasPendientes() {
    String listaTareas = "";

    for (int i = 0; i < listaDeTareas.size(); i++) {
        String[] tarea = listaDeTareas = Boolean.parseBoolean(tarea[1]);
        if (!estaTareaCompleta) {
            listaTareas = listaTareas + i + " - " + tarea[0] + " (" + tarea[2] + ")" + "\n";
        }
    }
    return listaTareas;
}

    public static string TareasCompletas() {
        String listaTareasCompl = "";

        for (int i = 0; i < listaDeTareas.size(); i++) {
            String[] tarea = listaDeTareas.get(i);
            booleanestaTareacompleta = Boolean.parseBoolean(tarea[1]);
            if (estaTareaCompleta) {
                listaTareasCompl = listaTareasCompl +i +" - "+ tarea[0] + " (" + tarea[2] + ")"+ "\n";
            }
        }
        return listaTareasCompl;
    }

public static string TareasCompletas() {
        String listaTareasCompl = "";

        for (int i = 0; i < listaDeTareas.size(); i++) {
            String[] tarea = listaDeTareas.get(i);
                listaTareas = listaTareas +i +" - "+ tarea[0] + " (" + tarea[2] + ")"+ "\n";
            }
        }
        return listaTareas;
}

public static boolean eliminarTarea(int i) {

if(i>=0 && i<listaDeTareas.size()){
        listaDeTareas.remove(i);
        return true;
}else {
    return false
    }
}

public static void Actualiza(int i,string antualizaDescripcion) {
    string detalle = "";
    string[] tarea = listaDeTareas.get(i);
    tarea[0] 0 actualizaDescripcion;
}

    public static string detalleTarea(int i) {
        string detalle = "";
        string[] tarea = listaDeTareas.get(i);
        detalle= detalle +i +" - "+ tarea[0] + " (" + tarea[2] + ")"+ "\n";
}

    }
}